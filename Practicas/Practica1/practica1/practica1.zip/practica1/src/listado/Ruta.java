package listado;

/**
 * Enumerado para representar los códigos de las rutas
 * de la empresa
 */
public enum Ruta {
    RUTA1, RUTA2, RUTA3, NORUTA
}
