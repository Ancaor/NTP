package listado;

/**
 * Enumerado para representar los sectores de actuacion de
 * los comerciales
 */
public enum Sector {
   SECTOR1, SECTOR2, NOSECTOR
}
